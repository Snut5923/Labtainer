from scapy.all import sniff, Raw
def packet_handler(packet):
    if packet.haslayer(Raw):
        payload = packet[Raw].load
        print(f"[LOG] Data FTP: {payload}")  
print("[*] Catching data FTP from user1 (192.168.0.10) to user2 (192.168.0.20)...")
sniff(iface="eth0", filter="tcp port 21", prn=packet_handler)


from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextLineHorizontal, LTTextBoxHorizontal
import statistics

def analyze_and_decode_line_shift(pdf_file):
    print(f"Analyzing {pdf_file} for hidden message using line shift technique...")
    pages_y_positions = []

    # y location of each line
    for page_index, page_layout in enumerate(extract_pages(pdf_file)):
        y_positions = []
        for element in page_layout:
            if isinstance(element, LTTextBoxHorizontal):
                for line in element:
                    if isinstance(line, LTTextLineHorizontal):
                        y = line.y1
                        text = line.get_text().strip()
                        y_positions.append((y, text))
        if y_positions:
            y_positions.sort(reverse=True)  # Sắp xếp từ trên xuống
            pages_y_positions.append(y_positions)

    if not pages_y_positions:
        print("No text lines found in the PDF!")
        return

    all_gaps = []
    for y_positions in pages_y_positions:
        gaps = [y_positions[i][0] - y_positions[i + 1][0] for i in range(len(y_positions) - 1)]
        all_gaps.extend(gaps)

    if not all_gaps:
        print("Not enough lines to analyze!")
        return

    # line_height
    line_height = statistics.mean(all_gaps)
    std_gap = statistics.stdev(all_gaps) if len(all_gaps) > 1 else 0
    print(f"Estimated line height: {line_height:.2f}, Std dev: {std_gap:.2f}")

    # Detect shift_amount
    shift_candidates = [abs(gap - line_height) for gap in all_gaps if abs(gap - line_height) > 0.1]
    shift_amount = statistics.mean(shift_candidates) if shift_candidates else 0
    print(f"Estimated shift amount: {shift_amount:.2f}")

    if shift_amount == 0:
        print("No significant line shifts detected!")
        return

    # Giải mã thông điệp
    binary_message = ""
    tolerance = shift_amount * 0.8  # tolerance to detect shifting

    for page_index, y_positions in enumerate(pages_y_positions):
        if len(y_positions) < 2:
            continue

        reference_y, _ = y_positions[0]  # First line to reference
        print(f"\nPage {page_index + 1}: Reference line y = {reference_y:.2f}")

        for i, (y, text) in enumerate(y_positions[1:], start=1):
            expected_y = reference_y - (i * line_height)
            delta = y - expected_y

            if abs(delta - shift_amount) < tolerance:
                binary_message += "0"
                print(f"Line {i + 1}: y = {y:.2f}, Expected = {expected_y:.2f}, Bit = 0")
            elif abs(delta + shift_amount) < tolerance:
                binary_message += "1"
                print(f"Line {i + 1}: y = {y:.2f}, Expected = {expected_y:.2f}, Bit = 1")
            else:
                print(f"Line {i + 1}: y = {y:.2f}, No significant shift detected")

    if not binary_message:
        print("No hidden message detected!")
        return

    # Binary to message
    print(f"\nBinary message: {binary_message}")
    if len(binary_message) % 8 != 0:
        print(f"Warning: Binary length {len(binary_message)} is not a multiple of 8, padding with zeros")
        binary_message += "0" * (8 - len(binary_message) % 8)

    try:
        decoded_message = "".join(chr(int(binary_message[i:i + 8], 2)) for i in range(0, len(binary_message), 8))
        print(f"Decoded message: {decoded_message}")
    except ValueError:
        print("Error: Could not decode binary into readable text!")

if __name__ == "__main__":
    pdf_file = "output.pdf"
    analyze_and_decode_line_shift(pdf_file)

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextLineHorizontal, LTTextBoxHorizontal


def encode_line_shift_pdf(input_file, secret_message, output_pdf="output.pdf"):
    binary_message = ''.join(format(ord(c), '08b') for c in secret_message)
    print(f"Binary mesage: {binary_message}")

    pages_lines = []  
    print(f"Reading content from file PDF: {input_file}...")

    
    for page_layout in extract_pages(input_file):
        page_lines = []
        for element in page_layout:
            if isinstance(element, LTTextBoxHorizontal):
                for line in element:
                    if isinstance(line, LTTextLineHorizontal):
                        text = line.get_text().strip()
                        if text:
                            page_lines.append(text)
        pages_lines.append(page_lines)

    if sum(len(page) for page in pages_lines) < len(binary_message) + len(pages_lines):
        print("Error: Not enough line in PDF to hide message!")
        return

    c = canvas.Canvas(output_pdf, pagesize=letter)
    width, height = letter
    shift_amount = 0.25
    line_height = 12
    message_index = 0

    for page_index, lines in enumerate(pages_lines):
        y_position = height - 50  

        if lines:
            c.drawString(50, y_position, lines[0])  
            y_position -= line_height
            print(f"Page {page_index + 1}: Line reference: y = {y_position}")

        for i, line in enumerate(lines[1:]):
            if message_index < len(binary_message):
                bit = binary_message[message_index]
                new_y = y_position + shift_amount if bit == '0' else y_position - shift_amount
                c.drawString(50, new_y, line)
                print(f"Page {page_index + 1} - Line {i + 1}: y = {new_y} (bit {bit})")
                message_index += 1
            else:
                c.drawString(50, y_position, line)
            y_position -= line_height

        c.showPage() 

    c.save()
    print(f"Save in {output_pdf}")


# Ví dụ sử dụng
input_file = "/home/ubuntu/input.pdf"
secret_message = "i_am_ptiter"
encode_line_shift_pdf(input_file, secret_message)


from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextLineHorizontal, LTTextBoxHorizontal


def decode_line_shift_pdf(input_pdf):
    print("Getting element from PDF...")
    pages_y_positions = []  

    for page_index, page_layout in enumerate(extract_pages(input_pdf)):
        y_positions = []
        print(f"Page {page_index + 1}:")
        for element in page_layout:
            if isinstance(element, LTTextBoxHorizontal):
                for line in element:
                    if isinstance(line, LTTextLineHorizontal):
                        y = line.y1
                        text = line.get_text().strip()
                        y_positions.append((y, text))
        if y_positions:
            y_positions.sort(reverse=True)  
            pages_y_positions.append(y_positions)

    binary_message = ""
    shift_amount = 0.25
    line_height = 12

    for page_index, y_positions in enumerate(pages_y_positions):
        if len(y_positions) < 2:
            continue

        reference_y, _ = y_positions[0]
        print(f"\n Page {page_index + 1}: Reference line y = {reference_y}")

        for i, (y, text) in enumerate(y_positions[1:], start=1):
            expected_y = reference_y - (i * line_height)
            delta = y - expected_y

            if abs(delta - shift_amount) < 0.2:
                binary_message += "0"
                print(f"Page {page_index + 1} - Line {i + 1}: y = {y}, bit 0")
            elif abs(delta + shift_amount) < 0.2:
                binary_message += "1"
                print(f"Page {page_index + 1} - Line {i + 1}: y = {y}, bit 1")
            else:
                print(f"Page {page_index + 1} - Line {i + 1}: stop decrypt")
                break

    if len(binary_message) % 8 != 0:
        print("Alert: Binary message dont have enough bytes!")
    print(f"\nBinary mesage: {binary_message}")
    decoded_message = "".join(chr(int(binary_message[i:i + 8], 2)) for i in range(0, len(binary_message), 8))
    print(f"\nMesage: {decoded_message}")


decode_line_shift_pdf("/home/ubuntu/output.pdf")

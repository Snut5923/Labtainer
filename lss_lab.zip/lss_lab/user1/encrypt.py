from docx import Document
from docx.shared import Pt


def hide_message_in_word(input_docx, secret_message, output_docx="output.docx"):
    # Read file 
    doc = Document(input_docx)

    # To binary
    binary_message = ''.join(format(ord(c), '08b') for c in secret_message)
    print(f"Binary message : {binary_message}")

    # Hide via spacing
    paragraphs = doc.paragraphs  
    j = 0
    for i, paragraph in enumerate(paragraphs):
        if i < len(binary_message):
            bit = binary_message[i]
            if bit == '0':
                spacing = Pt(9)  
            else:
                spacing = Pt(12)  
        else:
            spacing = Pt(10)  
        j = i
        paragraph.paragraph_format.space_after = spacing
    if j < len(binary_message) : print("Error")
    # Save file output
    else :
        doc.save(output_docx)
        print(f"Save in {output_docx}")

input_docx = "/home/ubuntu/input.docx"  
secret_message = "i_am_ptiter" 

hide_message_in_word(input_docx, secret_message)

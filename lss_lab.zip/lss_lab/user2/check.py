# check_input.py
expected_value = "i_am_ptiter"

user_input = input("Secret message: ")

if user_input == expected_value:
    print("Correct message")
else:
    print("Incorrect message")



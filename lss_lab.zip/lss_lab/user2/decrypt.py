import docx


def extract_message_from_word(input_docx):
    # Read file
    doc = docx.Document(input_docx)

    # Get spacing
    binary_message = ""
    for paragraph in doc.paragraphs:
        space_after = paragraph.paragraph_format.space_after
        if space_after:
            space_value = space_after.pt  

            # Get bit
            if space_value == 9:  
                binary_message += "0"
            elif space_value == 12:  
                binary_message += "1"

    print(f"Binary message : {binary_message}")

    # To message
    secret_message = ""
    for i in range(0, len(binary_message), 8):  
        byte = binary_message[i:i + 8]
        if len(byte) == 8:
            secret_message += chr(int(byte, 2))

    print(f"Secret message: {secret_message}")
    return secret_message

input_docx = "/home/ubuntu/output.docx"  

extract_message_from_word(input_docx)
